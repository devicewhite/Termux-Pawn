#!/bin/bash
pkg install pawndisasm -y &> /dev/null


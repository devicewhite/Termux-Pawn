#!/bin/bash
pkg install pawncc -y &> /dev/null


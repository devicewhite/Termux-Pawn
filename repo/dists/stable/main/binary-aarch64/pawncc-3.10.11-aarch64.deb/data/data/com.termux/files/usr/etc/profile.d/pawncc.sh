#!/bin/bash
pkg install pawncc-11 -y &> /dev/null &

